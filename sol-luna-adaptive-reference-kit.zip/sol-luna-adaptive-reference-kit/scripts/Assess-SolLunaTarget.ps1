[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [string]$CodexRoot
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'SilentlyContinue'

function Resolve-CodexRoot {
    param([string]$RequestedRoot)

    if (-not [string]::IsNullOrWhiteSpace($RequestedRoot)) {
        try {
            return [System.IO.Path]::GetFullPath($RequestedRoot)
        }
        catch {
            return $RequestedRoot
        }
    }

    $environmentRoot = [Environment]::GetEnvironmentVariable('CODEX_HOME')
    if (-not [string]::IsNullOrWhiteSpace($environmentRoot)) {
        try {
            return [System.IO.Path]::GetFullPath($environmentRoot)
        }
        catch {
            return $environmentRoot
        }
    }

    $profileRoot = [Environment]::GetFolderPath('UserProfile')
    if (-not [string]::IsNullOrWhiteSpace($profileRoot)) {
        return (Join-Path -Path $profileRoot -ChildPath '.codex')
    }

    return (Get-Location).Path
}

function Get-CandidatePathState {
    param(
        [string]$Root,
        [string]$RelativePath
    )

    $fullPath = Join-Path -Path $Root -ChildPath $RelativePath
    $isDirectory = Test-Path -LiteralPath $fullPath -PathType Container
    $isFile = Test-Path -LiteralPath $fullPath -PathType Leaf
    $kind = if ($isDirectory) { 'directory' } elseif ($isFile) { 'file' } else { 'missing' }

    return [ordered]@{
        relative_path = $RelativePath
        full_path = $fullPath
        exists = [bool]($isDirectory -or $isFile)
        kind = $kind
    }
}

function Read-CandidateText {
    param(
        [string]$FullPath,
        [string]$Kind
    )

    if ($Kind -eq 'missing') {
        return ''
    }

    $parts = New-Object 'System.Collections.Generic.List[string]'
    try {
        if ($Kind -eq 'file') {
            [void]$parts.Add([System.IO.File]::ReadAllText($FullPath))
        }
        else {
            $files = @(Get-ChildItem -LiteralPath $FullPath -Recurse -File -Force -ErrorAction SilentlyContinue)
            foreach ($file in $files) {
                try {
                    [void]$parts.Add([System.IO.File]::ReadAllText($file.FullName))
                }
                catch {
                    continue
                }
            }
        }
    }
    catch {
        return ''
    }

    return ($parts -join "`n")
}

$resolvedRoot = Resolve-CodexRoot -RequestedRoot $CodexRoot

$candidateSurfaces = [ordered]@{
    using_superpowers = @('skills/using-superpowers')
    model_routing = @('skills/model-routing')
    workflow_router = @(
        'agents/workflow-router.toml'
        'agents/workflow-router.yaml'
        'agents/workflow-router.yml'
    )
    global_maps = @(
        'global-agent-map'
        'global-agent-map.yaml'
        'global-agent-map.yml'
        'global-agent-map.json'
        'maps'
    )
    sol_luna_skill = @('skills/sol-luna-orchestration')
}

$markerDefinitions = [ordered]@{
    using_superpowers = @('using-superpowers', 'execution_required')
    model_routing = @('model-routing', 'gpt-5.6-luna', 'reasoning_effort')
    workflow_router = @('workflow-router', 'execution_required', 'lane')
    global_maps = @('agent', 'skill', 'route')
    sol_luna_skill = @('Root Sol', 'gpt-5.6-luna', 'fork_context: false')
}

$pathStates = [ordered]@{}
$markerStates = [ordered]@{}

foreach ($surfaceName in $candidateSurfaces.Keys) {
    $surfacePaths = New-Object 'System.Collections.Generic.List[object]'
    $surfaceTexts = New-Object 'System.Collections.Generic.List[string]'

    foreach ($relativePath in $candidateSurfaces[$surfaceName]) {
        $state = Get-CandidatePathState -Root $resolvedRoot -RelativePath $relativePath
        [void]$surfacePaths.Add($state)
        if ($state.exists) {
            [void]$surfaceTexts.Add((Read-CandidateText -FullPath $state.full_path -Kind $state.kind))
        }
    }

    $pathStates[$surfaceName] = @($surfacePaths.ToArray())
    $combinedText = $surfaceTexts -join "`n"
    $surfaceMarkers = [ordered]@{}
    foreach ($literal in $markerDefinitions[$surfaceName]) {
        $surfaceMarkers[$literal] = ($combinedText.IndexOf($literal, [StringComparison]::OrdinalIgnoreCase) -ge 0)
    }
    $markerStates[$surfaceName] = $surfaceMarkers
}

$agentsRoot = Join-Path -Path $resolvedRoot -ChildPath 'agents'
$skillsRoot = Join-Path -Path $resolvedRoot -ChildPath 'skills'
$agentFiles = @()
$skillDirectories = @()
if (Test-Path -LiteralPath $agentsRoot -PathType Container) {
    $agentFiles = @(Get-ChildItem -LiteralPath $agentsRoot -File -Force -ErrorAction SilentlyContinue)
}
if (Test-Path -LiteralPath $skillsRoot -PathType Container) {
    $skillDirectories = @(Get-ChildItem -LiteralPath $skillsRoot -Directory -Force -ErrorAction SilentlyContinue)
}

$result = [ordered]@{
    resolved_root = $resolvedRoot
    resolved_codex_root = $resolvedRoot
    codex_home_source = if (-not [string]::IsNullOrWhiteSpace($CodexRoot)) { 'parameter' } elseif (-not [string]::IsNullOrWhiteSpace([Environment]::GetEnvironmentVariable('CODEX_HOME'))) { 'environment' } else { 'user_profile_fallback' }
    path_states = $pathStates
    marker_states = $markerStates
    agent_count = $agentFiles.Count
    skill_count = $skillDirectories.Count
    manual_host_preflight_required = $true
    read_only_assessment = $true
}

Write-Output ($result | ConvertTo-Json -Depth 12 -Compress)
