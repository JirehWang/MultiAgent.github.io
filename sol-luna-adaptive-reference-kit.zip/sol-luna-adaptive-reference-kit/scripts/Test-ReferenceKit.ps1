[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = [System.IO.Path]::GetFullPath((Join-Path -Path $PSScriptRoot -ChildPath '..'))
$allowlist = @(
    'START-HERE.md'
    'ADAPTIVE-LANDING-GUIDE.md'
    'TARGET-AGENT-PROMPT.md'
    'core/sol-luna-orchestration/SKILL.md'
    'core/sol-luna-orchestration/references/task-packet.md'
    'core/sol-luna-orchestration/agents/openai.yaml'
    'contracts/execution-policy.yaml'
    'contracts/router-output-contract.yaml'
    'contracts/integration-surfaces.md'
    'scripts/Assess-SolLunaTarget.ps1'
    'scripts/Test-ReferenceKit.ps1'
)

$failures = New-Object 'System.Collections.Generic.List[string]'

function Add-Failure {
    param([string]$Message)
    [void]$script:failures.Add($Message)
}

function Get-RelativePackagePath {
    param([string]$FullPath)
    return $FullPath.Substring($root.Length + 1).Replace('\', '/')
}

function Read-PackageText {
    param([string]$RelativePath)
    return [System.IO.File]::ReadAllText((Join-Path -Path $root -ChildPath $RelativePath))
}

$actualFiles = @(
    Get-ChildItem -LiteralPath $root -Recurse -File -Force |
        ForEach-Object { Get-RelativePackagePath -FullPath $_.FullName }
)
$expectedFiles = @($allowlist | Sort-Object)
$observedFiles = @($actualFiles | Sort-Object)
$fileDifferences = @(Compare-Object -ReferenceObject $expectedFiles -DifferenceObject $observedFiles)
foreach ($difference in $fileDifferences) {
    if ($difference.SideIndicator -eq '<=') {
        Add-Failure "Missing allowlisted file: $($difference.InputObject)"
    }
    elseif ($difference.SideIndicator -eq '=>') {
        Add-Failure "Unexpected file: $($difference.InputObject)"
    }
}
if ($actualFiles.Count -ne 11) {
    Add-Failure "Expected exactly 11 files; found $($actualFiles.Count)."
}

$allText = New-Object 'System.Collections.Generic.List[string]'
$forbiddenUserToken = -join (@(49, 48, 53, 50, 50, 49) | ForEach-Object { [char]$_ })
foreach ($relativePath in $actualFiles) {
    try {
        $text = Read-PackageText -RelativePath $relativePath
        [void]$allText.Add($text)

        if ($text.IndexOf($forbiddenUserToken, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
            Add-Failure "Machine-specific user identifier found in $relativePath."
        }
        if ($text -match '(?i)C:\\Users\\') {
            Add-Failure "Machine-specific user path found in $relativePath."
        }

        $fenceCount = ([regex]::Matches($text, '(?m)^\s*```')).Count
        if (($fenceCount % 2) -ne 0) {
            Add-Failure "Unbalanced Markdown fences in $relativePath."
        }
    }
    catch {
        Add-Failure "Could not read ${relativePath}: $($_.Exception.Message)"
    }
}

$packageText = $allText -join "`n"
$requiredLiterals = @(
    'execution_required: false'
    'execution_required: true'
    'Root Sol'
    'gpt-5.6-luna'
    'reasoning_effort'
    'fork_context: false'
    'rollback'
    'add'
    'merge'
    'preserve'
    'not-applicable'
    '<REFERENCE_KIT_ROOT>'
    '<CODEX_HOME>'
    'manual_host_preflight_required'
    'read-only'
    'REFERENCE_KIT_OK'
)
foreach ($literal in $requiredLiterals) {
    if ($packageText.IndexOf($literal, [StringComparison]::OrdinalIgnoreCase) -lt 0) {
        Add-Failure "Required literal missing: $literal"
    }
}

$skillRelativePath = 'core/sol-luna-orchestration/SKILL.md'
if ($actualFiles -contains $skillRelativePath) {
    $skillText = Read-PackageText -RelativePath $skillRelativePath
    $frontmatterMatch = [regex]::Match($skillText, '(?ms)\A---\s*\r?\n(?<frontmatter>.*?)\r?\n---')
    if (-not $frontmatterMatch.Success) {
        Add-Failure 'Core SKILL.md is missing frontmatter.'
    }
    else {
        $frontmatter = $frontmatterMatch.Groups['frontmatter'].Value
        if ($frontmatter -notmatch '(?m)^name:\s*sol-luna-orchestration\s*$') {
            Add-Failure 'Core SKILL.md frontmatter name is incorrect.'
        }
        if ($frontmatter -notmatch '(?m)^description:\s*\S+') {
            Add-Failure 'Core SKILL.md frontmatter description is missing.'
        }
    }
}

function Test-YamlLikeFile {
    param([string]$RelativePath)

    $text = Read-PackageText -RelativePath $RelativePath
    if ($text -match "`t") {
        Add-Failure "Tab indentation found in YAML-like file $RelativePath."
    }

    $mappingCount = 0
    foreach ($line in ($text -split "`r?`n")) {
        $trimmed = $line.Trim()
        if ([string]::IsNullOrWhiteSpace($trimmed) -or $trimmed.StartsWith('#')) {
            continue
        }
        if ($trimmed -match '^(?:-\s+)?[A-Za-z0-9_.-]+:\s*') {
            $mappingCount++
            continue
        }
        if ($trimmed -match '^[-\[\]{},\s].*$') {
            continue
        }
        if ($trimmed -match '^\|$|^>$') {
            continue
        }
    }
    if ($mappingCount -lt 3) {
        Add-Failure "YAML-like structure is too sparse in $RelativePath."
    }
}

foreach ($yamlPath in @(
    'core/sol-luna-orchestration/agents/openai.yaml'
    'contracts/execution-policy.yaml'
    'contracts/router-output-contract.yaml'
)) {
    if ($actualFiles -contains $yamlPath) {
        Test-YamlLikeFile -RelativePath $yamlPath
    }
}

foreach ($scriptPath in @(
    'scripts/Assess-SolLunaTarget.ps1'
    'scripts/Test-ReferenceKit.ps1'
)) {
    if (-not ($actualFiles -contains $scriptPath)) {
        continue
    }
    $tokens = $null
    $parseErrors = $null
    [System.Management.Automation.Language.Parser]::ParseFile(
        (Join-Path -Path $root -ChildPath $scriptPath),
        [ref]$tokens,
        [ref]$parseErrors
    ) | Out-Null
    if ($null -ne $parseErrors -and $parseErrors.Count -gt 0) {
        Add-Failure "PowerShell parse errors in $scriptPath."
    }
}

if ($failures.Count -gt 0) {
    foreach ($failure in $failures) {
        Write-Output "FAIL: $failure"
    }
    Write-Output 'REFERENCE_KIT_FAILED'
    exit 1
}

Write-Output 'REFERENCE_KIT_OK'
exit 0
