# Adaptive Landing Guide

## Purpose

Land the Sol–Luna orchestration contract on a new computer without assuming that
its global layout, agent format, tool names, model identifiers, or local policy
match this reference kit. The target Root Sol is the controller and final
acceptor. A generic GPT-5.6 Luna worker at Max is the production lane whenever
`execution_required: true`.

This guide is deliberately adaptive. `<REFERENCE_KIT_ROOT>` identifies this
package, and `<CODEX_HOME>` means the target-discovered global root. Neither
placeholder is a command to write to a fixed location.

## Required landing workflow

### 1. Resolve the target roots

Resolve `CODEX_HOME` from the target environment when present; otherwise inspect
the target's documented user-profile fallback. Resolve the actual global agents,
skills, capability, map, router, and policy roots from the host. Record the
observed absolute paths in the target packet, while keeping machine-specific
paths out of this reference kit. If more than one plausible root exists, record
the candidates and the evidence used to choose the active root.

### 2. Probe host schemas and prove Luna/Max support

Inspect the schemas exposed by the host's worker/subagent and tool mechanisms.
Confirm, with an actual capability probe or documented runtime evidence, that a
generic worker can run `gpt-5.6-luna` with Max reasoning. Do not infer capability
from a label, an old configuration, or an assumed tool name. If support is absent,
record the gap and stop before substantive production; this kit cannot install
Luna or silently downgrade the boundary.

### 3. Inventory the current global state

Read-only inventory must cover:

- existing agents and their schemas;
- existing skills and their instruction files;
- global agent maps and routing maps;
- workflow-router and model-routing files;
- using-superpowers or equivalent workflow policy;
- capability/tool registries and the host's local policy;
- any existing Sol–Luna orchestration surface.

Record file existence, format, relevant marker literals, and ownership. Read the
actual files before deciding whether a surface can be added or merged.

### 4. Create a file-scoped rollback snapshot before writes

Before any write, create a rollback point containing only the pre-change contents
and metadata for the exact files that the target plan may touch. Store it in a
target-approved location outside the active production surface, protect secrets,
and record hashes. A plan without a usable file-scoped rollback point is not
ready for implementation. Do not create snapshots, caches, logs, or backups in
this reference package.

### 5. Classify every intended surface

For every proposed file or map entry, assign exactly one classification:

| Classification | Meaning |
| --- | --- |
| `add` | No compatible surface exists; a bounded new surface is justified. |
| `merge` | A compatible surface exists; preserve its local policy and integrate only the missing contract. |
| `preserve` | The existing surface is authoritative or unrelated; leave it unchanged. |
| `not-applicable` | The host does not expose the surface or the contract does not apply. |

The matrix must name the discovered path, proposed change, owner, compatibility
decision, rollback coverage, and verification check. Do not classify by filename
alone.

### 6. Produce a target-specific plan and ownership/verification packet

The packet must be self-contained and follow
`core/sol-luna-orchestration/references/task-packet.md`. It must state the
capability, one primary semantic role, optional support roles, objective,
acceptance criteria, allowed and forbidden paths, dependencies, exact commands,
inspection evidence, authority limits, and return contract. Root Sol remains the
only acceptance authority.

The plan must preserve these semantic fields for the default internal lane:

```yaml
agent_type: worker
model: gpt-5.6-luna
reasoning_effort: max
fork_context: false
```

### 7. Implement the minimum compatible changes

Use the target's real formats and local policy. Add only missing surfaces and
merge only the smallest compatible contract. Preserve unrelated local changes,
existing named-agent role contracts, and host-specific routing behavior. Named
specialists may remain advisory or validation roles; they do not become the
model-pinned production worker.

The following are explicit prohibitions:

- no blind copy;
- no whole-`.codex` replacement or whole-tree substitution;
- no machine-specific paths in portable instructions;
- no overwriting named agents;
- no repinning named agents;
- no assuming tool names or schemas;
- no silent model downgrade;
- no push, PR, or external coordination without explicit authorization.

### 8. Run target-specific verification

Run the adapted contract test against the target's actual paths. Then dispatch a
small but substantive Luna Max smoke task that exercises the true execution
boundary. Capture the worker packet, tool/model capability evidence, changed-file
diff, command output, and any warnings. A status message alone is not evidence.

The smoke task must show that Root Sol controls routing and inspection while the
generic `gpt-5.6-luna` worker performs the production operation. Do not use a
clarification-only task as the substantive smoke test.

### 9. Root Sol inspects and accepts or rolls back

Root Sol compares the actual diff and evidence with the target-specific plan,
checks for scope expansion, validates the semantic contract, and judges whether
the smoke task proves the runtime lane. If the acceptance criteria fail, issue a
precise correction packet or use the file-scoped rollback point. Root Sol must
make the final accept/rollback decision and report remaining risk. This guide
does not claim acceptance on the target's behalf.

## Stop conditions

Stop before substantive writes when the active root is unresolved, the rollback
point cannot be created, host schemas are unavailable, Luna/Max support is not
proven, ownership overlaps an unrelated change, or local policy would be
silently weakened. Return the evidence and the smallest question that unblocks
the next control-plane decision.
