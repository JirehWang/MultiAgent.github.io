# Integration Surfaces

This is a target-inspection map, not an instruction to copy a directory. Resolve
`<CODEX_HOME>` and the actual global roots on the target first. For each surface,
record the observed path, file format, local owner, compatibility evidence, and
one of `add`, `merge`, `preserve`, or `not-applicable`.

| Surface | Candidate target location | What to inspect | Classification guidance | Owner / evidence |
| --- | --- | --- | --- | --- |
| Workflow policy | `<CODEX_HOME>/skills/using-superpowers` or target-discovered equivalent | Skill instructions, routing order, validation tier, local policy | `merge` only missing compatible rules; otherwise `preserve` | Root Sol; actual file inspection |
| Model routing | `<CODEX_HOME>/skills/model-routing` or target-discovered equivalent | Model selection schema, capability registry links, role contracts | `merge` the semantic boundary without changing host schema | Root Sol plus routing evidence |
| Workflow router | `<CODEX_HOME>/agents/workflow-router.*` or target-discovered router surface | Agent schema, route output, execution flag, lane selection | `preserve` local authority; `merge` only an explicit contract gap | Root Sol; parsed schema and diff |
| Global maps | `<CODEX_HOME>/global-agent-map`, map files, or target-discovered map roots | Agent/skill ownership, lookup order, aliases, scopes | `add` only when the target has no compatible map entry | Root Sol; map evidence |
| Sol–Luna skill | `<CODEX_HOME>/skills/sol-luna-orchestration` or target-discovered skill root | Frontmatter, hard boundary, task packet, runtime lane fields | `add` or `merge` according to actual contents | Root Sol; skill inspection and quick validation |
| Capability/tool registry | `<CODEX_HOME>/capabilities` or target-discovered registry | Actual tool names, schemas, model support, permissions | `preserve` host truth; never infer names from this kit | Root Sol; host probe output |
| Named specialist agents | `<CODEX_HOME>/agents/<named-specialist>.*` | Role semantics, model binding, local ownership, dependencies | `preserve`; they remain semantic role contracts | Existing owner; diff and policy evidence |
| Local policy and controls | Target-discovered policy roots | Write boundaries, approvals, safety rules, validation commands | `preserve` unless Root Sol explicitly documents a compatible addition | Root Sol; policy evidence |

## Required matrix fields

The target packet must include, for every intended surface:

- discovered absolute path and format;
- classification (`add`, `merge`, `preserve`, or `not-applicable`);
- reason based on observed content;
- exact file-scoped rollback coverage;
- write owner and forbidden paths;
- target-specific contract test;
- substantive Luna Max smoke evidence;
- Root Sol acceptance or rollback judgment.

## Compatibility boundaries

The portable semantic contract is stable, but host syntax is not. A target may
have TOML, YAML, JSON, Markdown, or another documented schema. Preserve the
host's valid format and local policy. Do not assume tool names, model aliases,
directory names, or map keys. Do not overwrite or repin named agents. Do not
perform a whole-`.codex` substitution. Do not put machine-specific paths in
portable instructions.
