# Luna Max Task Packet

Every Luna execution lane receives a self-contained packet. Replace every placeholder;
the worker must not need the parent conversation to infer ownership or acceptance.

```yaml
role:
  capability: <capability id or none>
  primary_role: <selected semantic role>
  support_roles: []
  attached_skills: []

objective: <observable outcome and why it matters>
acceptance_criteria:
  - <observable pass condition>

ownership:
  allowed_paths: []
  forbidden_paths: []
  responsibility: <bounded responsibility>

interfaces_and_constraints:
  - <signature, schema, behavior, safety, or compatibility boundary>

starting_state:
  project: <project or projectless context>
  environment: <current workspace, worktree, or local task>
  base: <branch, ref, or exact observed state>
  dependencies: []

verification:
  validation_tier: <basic, standard, multi_stage, or high_risk>
  commands:
    - run: <exact command>
      success: <expected exit status and evidence>
  inspections:
    - inspect: <artifact, diff, or output>
      success: <required evidence>

authority:
  may_expand_scope: false
  may_modify_outside_ownership: false
  may_commit: false
  may_push: false
  may_open_or_modify_pr: false

return_contract:
  status: <complete, partial, or blocked>
  objective: <one-line restatement>
  changed_files: []
  produced_artifacts: []
  verification_evidence: []
  judgment_calls: []
  gaps: []
```

## Worker rules

- Preserve unrelated user and worker changes.
- Do not redesign settled architecture or broaden scope.
- Stop and report a blocker when ownership or prerequisites are unclear.
- Report actual commands and evidence, not predicted results.
- Do not claim acceptance; only Root Sol accepts the work.

## Small-task packet

Small work still goes to Luna, but the packet may be compressed to:

```yaml
role: <semantic role>
objective: <single outcome>
ownership: <one file or one bounded responsibility>
constraints: []
verification: <one exact check>
return: <result, evidence, changed files, gaps>
```

The compressed packet may omit empty ceremony, but it may not omit objective, ownership,
verification, or evidence.

