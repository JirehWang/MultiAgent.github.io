---
name: sol-luna-orchestration
description: Use when a request requires substantive execution and Root Sol must remain the controller and final acceptor while GPT-5.6 Luna / Max workers perform all production work.
---

# Sol–Luna Orchestration

Separate control from execution.

- Root Sol owns understanding, clarification, routing, decomposition, correction,
  verification, and final acceptance.
- GPT-5.6 Luna at Max reasoning owns production work.
- Existing agents, capabilities, and skills supply semantic roles and domain contracts;
  they do not replace the Luna runtime for execution.

## Hard boundary

```text
IF execution_required = true
THEN Root Sol MUST NOT execute
AND Root Sol MUST dispatch at least one GPT-5.6 Luna / Max worker.
```

Root Sol must not write the implementation, edit the artifact, run the production
operation as a substitute for a worker, or quietly finish a failed worker's task. Task
size never relaxes this boundary.

Root Sol may perform only control-plane work:

- understand and clarify intent;
- select capability, primary role, support roles, and validation tier;
- define acceptance criteria, ownership, dependencies, and task packets;
- inspect outputs, diffs, tool evidence, and verification results; and
- accept, correct, replan, block, or report status.

## Classify execution

Set `execution_required: false` only for clarification, routing, decomposition,
approval, rejection, verification judgment, and status reporting.

Set `execution_required: true` when the request requires any substantive artifact,
code or file change, research or analysis result, test or build, extraction, external
tool operation, or content that becomes the main answer or decision input.

When uncertain, treat substantive production as execution and delegate it.

## Preserve semantic routing

Run normal routing first:

1. Use `using-superpowers` to select workflow and validation tier.
2. Check the capability registry for a narrow specialist.
3. Select exactly one primary semantic role and zero to two support roles.
4. Preserve those roles as the worker's role contract.
5. Apply this skill as the runtime overlay when `execution_required: true`.

Do not spawn a model-pinned specialist custom agent as the implementation worker merely
because its role matched. Use a generic Luna worker and attach the selected skill or a
complete role capsule. Specialist custom agents may remain advisory or validation gates
when the route explicitly requires one, but Root Sol retains acceptance authority.

## Choose a lane

> Host-schema note: names such as `list_projects`, `create_thread`, `wait_threads`,
> and `read_thread` below are source-host examples only. The target must map the
> semantic lane to its actually exposed tool and subagent schema, and must stop
> before substantive production if support for Luna/Max cannot be proven.

### `internal_luna` — default

Use native subagents for normal execution:

```yaml
agent_type: worker
model: gpt-5.6-luna
reasoning_effort: max
fork_context: false
```

Give every worker a complete packet from
[references/task-packet.md](references/task-packet.md). Attach the selected skill when
the spawn mechanism supports skill input; otherwise include the exact role contract in
the packet.

### `visible_luna_task` — explicit opt-in

Use a user-visible Codex task only when the user's current request explicitly asks for
that lane. Call `list_projects` before `create_thread`, use a worktree for a Git project
unless the user selects another allowed starting state, set `model` to `gpt-5.6-luna`
and `thinking` to `max`, then monitor with `wait_threads` and inspect with
`read_thread`.

A visible Luna task may not push, open, update, or merge a PR until Root Sol has
inspected the actual diff and checks and explicitly authorizes that action.

## Scale by task shape

- Small or obvious execution: one Luna worker, short packet, one focused check.
- Normal single-surface work: one Luna worker with the relevant semantic role.
- Independent slices: two to three Luna workers with disjoint ownership.
- Pure read-only independent work: up to four Luna workers.
- Shared-file or dependent work: serialize workers through an explicit dependency DAG.

Do not create parallel workers from task count alone. Never give two workers overlapping
write ownership.

## Verify and correct

Treat every worker report as a claim. Root Sol must inspect the actual artifact or diff,
check scope, and evaluate or rerun the required verification before acceptance.

If work is wrong:

1. Send a precise correction packet to the same worker or visible task when practical.
2. Include the failed evidence and required acceptance condition.
3. Allow one corrected re-review for the same finding set.
4. If failure repeats, stop execution and replan instead of spawning more workers.

Root Sol must never rescue the implementation directly.

## Completion gate

Completion requires all of the following:

- at least one Luna Max worker was used when `execution_required: true`;
- each worker had explicit role, objective, ownership, constraints, verification, and
  return contract;
- Root Sol inspected concrete output and evidence;
- required specialist or risk gates completed without silent downgrade; and
- Root Sol made the final acceptance decision.

Run the reference-kit package check first:

```powershell
powershell -ExecutionPolicy Bypass -File <REFERENCE_KIT_ROOT>/scripts/Test-ReferenceKit.ps1
```

After adaptive integration, derive and run a target-specific contract test against
the target's actual paths and exposed schemas. Root Sol must inspect that evidence
before acceptance.
