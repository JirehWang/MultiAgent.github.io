# Sol–Luna Adaptive Reference Kit

This is an independent, reference-only landing kit for a target computer whose
Root Sol must adapt the Sol–Luna workflow to that host's actual global agents,
skills, maps, policies, and tool schemas. It is not a repository overlay and is
not a merge bundle.

Use the package directory as `<REFERENCE_KIT_ROOT>`. Treat the files under
`core/` and `contracts/` as canonical references. The target Root Sol decides
what is compatible, what must be preserved, and what evidence is sufficient.

## Read in this order

1. `ADAPTIVE-LANDING-GUIDE.md` — the required target workflow.
2. `TARGET-AGENT-PROMPT.md` — a copy/paste-ready instruction for the target Root Sol.
3. `contracts/execution-policy.yaml` — the control/execution boundary.
4. `contracts/router-output-contract.yaml` — the semantic routing result shape.
5. `contracts/integration-surfaces.md` — surfaces that require target inspection.
6. `core/sol-luna-orchestration/SKILL.md` and its task packet reference.
7. `scripts/Assess-SolLunaTarget.ps1` and `scripts/Test-ReferenceKit.ps1`.

## Non-negotiable semantics

- Root Sol owns understanding, clarification, semantic routing, decomposition,
  correction, evidence inspection, verification judgment, and final acceptance.
- Set `execution_required: false` only for clarification, routing, decomposition,
  approval/rejection, verification judgment, and status reporting.
- Set `execution_required: true` for substantive answers or decision inputs,
  artifacts, code/files, research/analysis, tests/builds, extraction, and
  external operations.
- When `execution_required: true`, Root Sol must not produce the substantive
  result. A generic GPT-5.6 Luna worker at Max performs production work.
- The default internal lane is semantic, not a promise about a host-specific
  tool name:

  ```yaml
  agent_type: worker
  model: gpt-5.6-luna
  reasoning_effort: max
  fork_context: false
  ```

- A visible task lane is allowed only when the current user explicitly requests
  that lane.
- Named specialist agents remain semantic role contracts. They are not to be
  overwritten or repinned as the Luna implementation worker.
- Tool and model availability belong to the target runtime. This kit cannot
  install Luna; the target must inspect and prove host support.

## Landing rule

The target Root Sol must first resolve the actual `<CODEX_HOME>` and global roots,
inspect host schemas, inventory the current state, and create a file-scoped
rollback snapshot. Only then may it classify surfaces and implement the minimum
compatible changes. It must run a target-specific contract test and a substantive
Luna Max smoke task. Root Sol must inspect the evidence and explicitly accept or
roll back; this package never claims that acceptance.

Do not push, open, update, or merge a PR unless the current user explicitly
authorizes that action.
