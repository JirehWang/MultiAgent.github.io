$ErrorActionPreference = 'Stop'

$projectRoot = $PSScriptRoot
$runtimeRoot = 'C:\Users\105221\Documents\Codex\global-runtimes\agents-sdk-pilot'
$runtimePython = Join-Path $runtimeRoot '.venv\Scripts\python.exe'
$stageRoot = Join-Path $projectRoot 'staged-global'
$checkpointArchive = 'C:\Users\105221\Documents\Codex\2026-07-29\https-github-com-openai-https-github\outputs\global-workflow-checkpoint-20260729-160533.zip'
$checkpointVerifyRoot = 'C:\Users\105221\Documents\Codex\2026-07-29\https-github-com-openai-https-github\work\checkpoint-verification\global-workflow-pre-agents-sdk-20260729-160533'
$restoreScript = 'C:\Users\105221\Documents\Codex\2026-07-29\https-github-com-openai-https-github\work\checkpoints\global-workflow-pre-agents-sdk-20260729-160533\RESTORE.ps1'

function Assert-True {
    param(
        [bool]$Condition,
        [string]$Message
    )
    if (-not $Condition) {
        throw $Message
    }
}

function Invoke-PilotRequest {
    param(
        [string]$Request
    )

    $env:PYTHONPATH = Join-Path $runtimeRoot 'src'
    $env:TIKTOKEN_CACHE_DIR = Join-Path $runtimeRoot 'tiktoken-cache'
    $env:AGENTS_SDK_PILOT_MODE = 'observe'
    $env:AGENTS_SDK_ENCODING = 'o200k_base'
    $env:AGENTS_SDK_CONTEXT_WINDOW = '200000'
    $env:AGENTS_SDK_RESERVED_OUTPUT_TOKENS = '8000'
    $env:AGENTS_SDK_WARN_RATIO = '0.80'
    $env:AGENTS_SDK_MAX_TURNS = '4'
    $env:AGENTS_SDK_TRACING_ENABLED = 'false'
    $env:OPENAI_AGENTS_DISABLE_TRACING = '1'
    Remove-Item Env:OPENAI_API_KEY -ErrorAction SilentlyContinue
    Remove-Item Env:AGENTS_SDK_MODEL -ErrorAction SilentlyContinue

    $messages = @(
        '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"deployment-verifier","version":"1.0"}}}',
        '{"jsonrpc":"2.0","method":"notifications/initialized","params":{}}',
        $Request
    )
    $raw = $messages | & $runtimePython -m global_agent_runtime.server
    Assert-True ($LASTEXITCODE -eq 0) 'Pilot MCP process failed.'
    $responses = @($raw | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | ForEach-Object { $_ | ConvertFrom-Json })
    Assert-True ($responses.Count -ge 2) 'Pilot MCP did not return the tool response.'
    return $responses[-1]
}

$env:PYTHONPATH = Join-Path $projectRoot 'src'
$env:TIKTOKEN_CACHE_DIR = Join-Path $projectRoot '.tiktoken-cache'
& (Join-Path $projectRoot '.venv\Scripts\python.exe') -m unittest discover -s (Join-Path $projectRoot 'tests') -v
Assert-True ($LASTEXITCODE -eq 0) 'Unit tests failed.'

python -c "import yaml; yaml.safe_load(open(r'C:\Users\105221\.codex\skills\using-superpowers\agent-routing-rules.yaml', encoding='utf-8')); print('yaml_valid')"
Assert-True ($LASTEXITCODE -eq 0) 'Deployed YAML is invalid.'
py -3.11 -c "import tomllib; tomllib.load(open(r'C:\Users\105221\.codex\config.toml','rb')); print('toml_valid')"
Assert-True ($LASTEXITCODE -eq 0) 'Deployed TOML is invalid.'

$deployedPairs = @(
    @((Join-Path $stageRoot 'config.toml'), 'C:\Users\105221\.codex\config.toml'),
    @((Join-Path $stageRoot 'skills\using-superpowers\SKILL.md'), 'C:\Users\105221\.codex\skills\using-superpowers\SKILL.md'),
    @((Join-Path $stageRoot 'skills\using-superpowers\agent-routing-rules.yaml'), 'C:\Users\105221\.codex\skills\using-superpowers\agent-routing-rules.yaml')
)
foreach ($pair in $deployedPairs) {
    $sourceHash = (Get-FileHash -LiteralPath $pair[0] -Algorithm SHA256).Hash
    $targetHash = (Get-FileHash -LiteralPath $pair[1] -Algorithm SHA256).Hash
    Assert-True ($sourceHash -eq $targetHash) "Deployed hash mismatch: $($pair[1])"
}

$mcpList = codex mcp list | Out-String
Assert-True ($LASTEXITCODE -eq 0) 'Codex could not parse global MCP configuration.'
Assert-True ($mcpList -match 'agents_sdk_pilot') 'Codex did not list agents_sdk_pilot.'
Assert-True ($mcpList -match 'agents_sdk_pilot[\s\S]*enabled') 'agents_sdk_pilot is not enabled.'

$listResponse = Invoke-PilotRequest '{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}'
$toolNames = @($listResponse.result.tools | ForEach-Object { $_.name } | Sort-Object)
Assert-True (($toolNames -join ',') -eq 'estimate_token_budget,run_agent_node,runtime_status') 'Unexpected MCP tool surface.'

$statusResponse = Invoke-PilotRequest '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"runtime_status","arguments":{}}}'
Assert-True (-not $statusResponse.result.isError) 'runtime_status returned an error.'
Assert-True ($statusResponse.result.structuredContent.mode -eq 'observe') 'Pilot is not in observe mode.'
Assert-True (-not $statusResponse.result.structuredContent.agent_execution_available) 'Agent execution unexpectedly enabled.'

$estimateResponse = Invoke-PilotRequest '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"estimate_token_budget","arguments":{"text":"Token observation integration test."}}}'
Assert-True (-not $estimateResponse.result.isError) 'estimate_token_budget returned an error.'
Assert-True ($estimateResponse.result.structuredContent.estimated_input_tokens -eq 5) 'Unexpected token estimate.'

$blockedResponse = Invoke-PilotRequest '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"run_agent_node","arguments":{"name":"blocked","instructions":"Do not run.","input_text":"test"}}}'
Assert-True ($blockedResponse.result.isError) 'run_agent_node must be denied in observe mode.'

$manifest = Import-Csv -LiteralPath (Join-Path $checkpointVerifyRoot 'SHA256SUMS.csv')
$snapshotRoot = Join-Path $checkpointVerifyRoot 'snapshot\.codex'
foreach ($entry in $manifest) {
    $candidate = Join-Path $snapshotRoot $entry.RelativePath
    Assert-True (Test-Path -LiteralPath $candidate -PathType Leaf) "Checkpoint file missing: $($entry.RelativePath)"
    $actual = (Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash
    Assert-True ($actual -eq $entry.SHA256) "Checkpoint hash mismatch: $($entry.RelativePath)"
}

$previousErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$restoreOutput = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $restoreScript 2>&1 | Out-String
$restoreExitCode = $LASTEXITCODE
$ErrorActionPreference = $previousErrorActionPreference
Assert-True ($restoreExitCode -ne 0) 'Restore script ran without explicit confirmation.'
Assert-True ($restoreOutput -match 'Restore not started') 'Restore confirmation guard did not report the expected message.'

$archiveHash = (Get-FileHash -LiteralPath $checkpointArchive -Algorithm SHA256).Hash
[pscustomobject]@{
    UnitTests = '18 passed'
    Toml = 'valid'
    Yaml = 'valid'
    DeployedHashes = 'match'
    CodexMcp = 'enabled'
    McpTools = ($toolNames -join ', ')
    TokenEstimate = $estimateResponse.result.structuredContent.estimated_input_tokens
    AgentExecution = 'denied in observe mode'
    CheckpointFiles = "$($manifest.Count) verified"
    CheckpointSHA256 = $archiveHash
    RestoreGuard = 'confirmed'
} | Format-List
