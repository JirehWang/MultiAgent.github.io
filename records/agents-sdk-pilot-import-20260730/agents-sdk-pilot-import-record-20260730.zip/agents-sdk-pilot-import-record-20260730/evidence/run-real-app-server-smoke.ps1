param(
    [string]$Workspace = 'C:\Users\105221\Documents\Codex\2026-07-29\https-github-com-openai-https-github',
    [string]$LogPath = 'C:\Users\105221\Documents\Codex\2026-07-29\https-github-com-openai-https-github\work\real-app-server-smoke-20260730.jsonl'
)

$ErrorActionPreference = 'Stop'

if (Test-Path -LiteralPath $LogPath) {
    throw "Log already exists: $LogPath"
}

$codex = Get-Command codex -ErrorAction Stop
$startInfo = New-Object System.Diagnostics.ProcessStartInfo
$startInfo.FileName = $codex.Source
$startInfo.Arguments = 'app-server --listen stdio://'
$startInfo.UseShellExecute = $false
$startInfo.RedirectStandardInput = $true
$startInfo.RedirectStandardOutput = $true
$startInfo.RedirectStandardError = $false
$startInfo.CreateNoWindow = $true

$process = New-Object System.Diagnostics.Process
$process.StartInfo = $startInfo

function Send-ProtocolMessage {
    param(
        [System.Diagnostics.Process]$Process,
        [object]$Message
    )

    $json = $Message | ConvertTo-Json -Compress -Depth 20
    $Process.StandardInput.WriteLine($json)
    $Process.StandardInput.Flush()
}

function Read-ProtocolMessage {
    param(
        [System.Diagnostics.Process]$Process,
        [int]$TimeoutMilliseconds
    )

    $readTask = $Process.StandardOutput.ReadLineAsync()
    if (-not $readTask.Wait($TimeoutMilliseconds)) {
        throw "Timed out waiting for app-server output after $TimeoutMilliseconds ms."
    }
    $line = $readTask.Result
    if ($null -eq $line) {
        throw 'App-server closed stdout before the expected response.'
    }

    [System.IO.File]::AppendAllText($LogPath, $line + [Environment]::NewLine)
    return $line | ConvertFrom-Json
}

function Read-UntilResponse {
    param(
        [System.Diagnostics.Process]$Process,
        [object]$RequestId,
        [int]$TimeoutMilliseconds
    )

    $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMilliseconds)
    while ([DateTime]::UtcNow -lt $deadline) {
        $remaining = [int][Math]::Max(1, ($deadline - [DateTime]::UtcNow).TotalMilliseconds)
        $message = Read-ProtocolMessage -Process $Process -TimeoutMilliseconds $remaining
        if ($null -ne $message.id -and [string]$message.id -eq [string]$RequestId) {
            return $message
        }
    }
    throw "Timed out waiting for response id $RequestId."
}

try {
    if (-not $process.Start()) {
        throw 'Failed to start codex app-server.'
    }

    Send-ProtocolMessage -Process $process -Message @{
        id = 1
        method = 'initialize'
        params = @{
            clientInfo = @{
                name = 'global-workflow-smoke'
                title = 'Global Workflow Smoke Test'
                version = '1.0'
            }
            capabilities = @{
                experimentalApi = $true
            }
        }
    }
    $initialize = Read-UntilResponse -Process $process -RequestId 1 -TimeoutMilliseconds 30000
    if ($null -ne $initialize.error) {
        throw "Initialize failed: $($initialize.error | ConvertTo-Json -Compress -Depth 10)"
    }

    Send-ProtocolMessage -Process $process -Message @{
        method = 'initialized'
        params = @{}
    }

    Send-ProtocolMessage -Process $process -Message @{
        id = 2
        method = 'thread/start'
        params = @{
            cwd = $Workspace
            ephemeral = $true
            approvalPolicy = 'never'
            sandbox = 'read-only'
            experimentalRawEvents = $true
        }
    }
    $threadStart = Read-UntilResponse -Process $process -RequestId 2 -TimeoutMilliseconds 30000
    if ($null -ne $threadStart.error) {
        throw "Thread start failed: $($threadStart.error | ConvertTo-Json -Compress -Depth 10)"
    }
    $threadId = $threadStart.result.thread.id
    if ([string]::IsNullOrWhiteSpace($threadId)) {
        throw 'Thread start response did not contain a thread id.'
    }

    $prompt = 'Read-only smoke test. Do not modify files. Follow the current global workflow rules. Perform token budget observation for the text below. If the rules select agents_sdk_pilot, actually call its estimate_token_budget tool; do not invent a result. In the final answer, list the tool calls, returned values, and any errors. Test text: Global workflow node handoff token observation test.'
    Send-ProtocolMessage -Process $process -Message @{
        id = 3
        method = 'turn/start'
        params = @{
            threadId = $threadId
            input = @(
                @{
                    type = 'text'
                    text = $prompt
                    text_elements = @()
                }
            )
        }
    }
    $turnStart = Read-UntilResponse -Process $process -RequestId 3 -TimeoutMilliseconds 30000
    if ($null -ne $turnStart.error) {
        throw "Turn start failed: $($turnStart.error | ConvertTo-Json -Compress -Depth 10)"
    }

    $completed = $null
    $deadline = [DateTime]::UtcNow.AddSeconds(180)
    while ([DateTime]::UtcNow -lt $deadline) {
        $remaining = [int][Math]::Max(1, ($deadline - [DateTime]::UtcNow).TotalMilliseconds)
        $message = Read-ProtocolMessage -Process $process -TimeoutMilliseconds $remaining
        if ($message.method -eq 'turn/completed') {
            $completed = $message
            break
        }
    }
    if ($null -eq $completed) {
        throw 'Turn did not complete within 180 seconds.'
    }

    $turn = $completed.params.turn
    [pscustomobject]@{
        ThreadId = $threadId
        TurnId = $turn.id
        TurnStatus = $turn.status
        TurnError = if ($null -ne $turn.error) { $turn.error | ConvertTo-Json -Compress -Depth 10 } else { $null }
        LogPath = $LogPath
    } | Format-List
}
finally {
    if (-not $process.HasExited) {
        $process.StandardInput.Close()
        if (-not $process.WaitForExit(10000)) {
            $process.Kill()
            $process.WaitForExit()
        }
    }
    $process.Dispose()
}
