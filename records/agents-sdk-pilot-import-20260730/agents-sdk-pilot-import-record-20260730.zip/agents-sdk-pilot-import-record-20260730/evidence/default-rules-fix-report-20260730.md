# default.rules fix and smoke-test report

Date: 2026-07-30

## Fix

File:

`C:\Users\105221\.codex\rules\default.rules`

Line 270 changed from:

```text
// GSAP Skills routing: ...
```

to:

```text
# GSAP Skills routing: ...
```

This is the only changed line.

Pre-fix SHA-256:

`FB71FEF15A1CEA931DE806175647BCC16F8F689371F72B974549A555960D5CD9`

Post-fix SHA-256:

`EF91D421A5530F3439048348342F0EC63C6BAE0A445C2BBECAF1B485C9BE1046`

Rollback copy:

`outputs\default.rules.pre-fix-20260730`

## Real test results

Before the fix, `codex exec` exited 1 with:

```text
default.rules:270: starlark error: Parse error: unexpected symbol '//'
```

After the fix, the Starlark parse error no longer appears. `codex exec` advances to
app-server initialization, then the current shell host rejects process/IPC creation:

```text
Error: failed to initialize in-process app-server client: Access is denied. (os error 5)
```

Granting the exact SQLite files, temp paths, and then the entire `.codex` directory did not
change this result. Therefore this is not a filesystem ACL issue; it is a process/IPC
sandbox limitation of the current shell host.

The global router end-to-end turn is not claimed as passed.

## Runtime verification

The deployed MCP boundary was tested directly with real stdio calls:

- 18 tests passed.
- Global TOML and YAML parsed successfully.
- `agents_sdk_pilot` is enabled in Codex MCP configuration.
- Actual tool surface: `runtime_status`, `estimate_token_budget`, `run_agent_node`.
- `estimate_token_budget` returned 5 tokens for the integration input.
- `run_agent_node` was denied in observe mode as required.
- 67 checkpoint files passed SHA-256 verification.
