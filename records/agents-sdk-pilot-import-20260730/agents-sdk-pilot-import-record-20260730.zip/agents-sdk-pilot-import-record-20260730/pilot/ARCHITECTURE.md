# Agents SDK / tiktoken global pilot

Status: implementation

## Job and success signal

Add measurable token-budget visibility to the current global workflow and prepare one
feature-flagged Agents SDK node runtime without replacing the existing Codex router.

Success means:

- token estimation works locally without an API key;
- the current router remains the control plane;
- SDK handoffs, sessions, and direct tools are disabled;
- model execution requires both canary mode and an API key;
- restoring the checkpoint disables the integration.

## Topology and authority

```text
Codex global router (owns classification, state, approvals, tool policy)
  |
  +-- existing global agents and skills
  |
  +-- agents_sdk_pilot MCP
       +-- status / token budget (observe mode)
       +-- single node Runner (canary only)
```

The MCP runtime never chooses another global agent. It receives a bounded node request
from the existing control plane and returns one result.

## Contracts

| Surface | Input | Output | Authority |
|---|---|---|---|
| `runtime_status` | none | mode, versions, readiness flags | read-only |
| `estimate_token_budget` | text and optional budget | counts, utilization, status | advisory in observe mode |
| `run_agent_node` | name, instructions, text | final output and usage metadata | canary only |

## Failure and recovery

- Missing API key or model: token tools stay available; node execution returns unavailable.
- Budget exceeded: canary call is rejected before a model request.
- MCP startup failure: existing workflow continues without the pilot tool.
- Regression: restore `config.toml` and router files from the checkpoint, then restart Codex.
- The runtime is stored at `C:\Users\105221\Documents\Codex\global-runtimes\agents-sdk-pilot`;
  restoring global config makes it inert without deleting the directory.

## Observability

- No prompt text is written to logs.
- Runtime status exposes booleans, versions, and mode; never secrets.
- SDK tracing is disabled by default and requires an explicit environment opt-in.
- Actual API usage remains authoritative; tiktoken is an estimate.
