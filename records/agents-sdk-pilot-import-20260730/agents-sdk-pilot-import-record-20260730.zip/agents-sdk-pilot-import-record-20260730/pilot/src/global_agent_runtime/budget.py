from __future__ import annotations

from dataclasses import asdict, dataclass

import tiktoken


class BudgetExceeded(ValueError):
    """Raised when enforcement is enabled and estimated input exceeds the budget."""


@dataclass(frozen=True)
class TokenBudget:
    estimated_input_tokens: int
    context_window: int
    reserved_output_tokens: int
    remaining_tokens: int
    utilization: float
    status: str
    encoding: str
    used_model_encoding: bool

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _resolve_encoding(
    model: str | None,
    encoding_name: str,
) -> tuple[tiktoken.Encoding, bool]:
    if model:
        try:
            return tiktoken.encoding_for_model(model), True
        except KeyError:
            pass
    return tiktoken.get_encoding(encoding_name), False


def estimate_token_budget(
    text: str,
    *,
    model: str | None = None,
    encoding_name: str = "o200k_base",
    context_window: int = 200_000,
    reserved_output_tokens: int = 8_000,
    warn_ratio: float = 0.80,
    enforce: bool = False,
) -> TokenBudget:
    if context_window <= 0:
        raise ValueError("context_window must be positive")
    if reserved_output_tokens < 0 or reserved_output_tokens >= context_window:
        raise ValueError("reserved_output_tokens must be within the context window")
    if not 0 < warn_ratio <= 1:
        raise ValueError("warn_ratio must be between 0 and 1")

    encoding, used_model_encoding = _resolve_encoding(model, encoding_name)
    estimated = len(encoding.encode(text))
    usable_input_tokens = context_window - reserved_output_tokens
    remaining = usable_input_tokens - estimated
    utilization = estimated / usable_input_tokens

    if remaining < 0:
        status = "exceeded"
    elif utilization >= warn_ratio:
        status = "warn"
    else:
        status = "ok"

    result = TokenBudget(
        estimated_input_tokens=estimated,
        context_window=context_window,
        reserved_output_tokens=reserved_output_tokens,
        remaining_tokens=remaining,
        utilization=utilization,
        status=status,
        encoding=encoding.name,
        used_model_encoding=used_model_encoding,
    )

    if enforce and status == "exceeded":
        raise BudgetExceeded(
            f"estimated input is {-remaining} tokens over the configured input budget"
        )

    return result
