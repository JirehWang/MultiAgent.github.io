from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


def _as_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _as_int(value: str | None, default: int) -> int:
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def _as_float(value: str | None, default: float) -> float:
    if value is None:
        return default
    try:
        return float(value)
    except ValueError:
        return default


@dataclass(frozen=True)
class RuntimeSettings:
    mode: str
    api_key: str
    model: str
    encoding_name: str
    context_window: int
    reserved_output_tokens: int
    warn_ratio: float
    max_turns: int
    tracing_enabled: bool

    @classmethod
    def from_env(cls, env: Mapping[str, str]) -> "RuntimeSettings":
        requested_mode = env.get("AGENTS_SDK_PILOT_MODE", "observe").strip().lower()
        mode = requested_mode if requested_mode in {"off", "observe", "canary"} else "observe"
        max_turns = max(1, min(_as_int(env.get("AGENTS_SDK_MAX_TURNS"), 4), 4))
        context_window = max(1, _as_int(env.get("AGENTS_SDK_CONTEXT_WINDOW"), 200_000))
        reserve = max(
            0,
            min(
                _as_int(env.get("AGENTS_SDK_RESERVED_OUTPUT_TOKENS"), 8_000),
                context_window - 1,
            ),
        )
        warn_ratio = min(
            1.0,
            max(0.01, _as_float(env.get("AGENTS_SDK_WARN_RATIO"), 0.80)),
        )

        return cls(
            mode=mode,
            api_key=env.get("OPENAI_API_KEY", "").strip(),
            model=env.get("AGENTS_SDK_MODEL", "").strip(),
            encoding_name=env.get("AGENTS_SDK_ENCODING", "o200k_base").strip(),
            context_window=context_window,
            reserved_output_tokens=reserve,
            warn_ratio=warn_ratio,
            max_turns=max_turns,
            tracing_enabled=_as_bool(env.get("AGENTS_SDK_TRACING_ENABLED"), False),
        )

    @property
    def agent_execution_available(self) -> bool:
        return self.mode == "canary" and bool(self.api_key) and bool(self.model)

    def public_status(self) -> dict[str, object]:
        return {
            "mode": self.mode,
            "agent_execution_available": self.agent_execution_available,
            "api_key_present": bool(self.api_key),
            "model_configured": bool(self.model),
            "encoding": self.encoding_name,
            "context_window": self.context_window,
            "reserved_output_tokens": self.reserved_output_tokens,
            "warn_ratio": self.warn_ratio,
            "max_turns": self.max_turns,
            "tracing_enabled": self.tracing_enabled,
            "handoffs_enabled": False,
            "sessions_enabled": False,
            "direct_tools_enabled": False,
        }
