from __future__ import annotations

from importlib.metadata import version
import os
from typing import Any

from mcp.server.fastmcp import FastMCP

from .budget import estimate_token_budget as calculate_token_budget
from .runner import run_agent_node as execute_agent_node
from .settings import RuntimeSettings


def create_server(
    *,
    settings: RuntimeSettings | None = None,
    node_runner: Any = None,
) -> FastMCP:
    active_settings = settings or RuntimeSettings.from_env(os.environ)
    execute = node_runner or execute_agent_node
    server = FastMCP(
        "agents_sdk_pilot",
        instructions=(
            "Observe token budgets and run one bounded Agents SDK node only when "
            "the global canary gates are enabled."
        ),
        log_level="WARNING",
    )

    @server.tool(
        name="runtime_status",
        description="Read pilot mode, dependency versions, and readiness without exposing secrets.",
        structured_output=True,
    )
    def runtime_status() -> dict[str, object]:
        status = active_settings.public_status()
        status["openai_agents_version"] = version("openai-agents")
        status["tiktoken_version"] = version("tiktoken")
        status["token_policy"] = "observe"
        return status

    @server.tool(
        name="estimate_token_budget",
        description=(
            "Estimate text tokens with tiktoken. The result is advisory in this rollout phase; "
            "actual API usage remains authoritative."
        ),
        structured_output=True,
    )
    def estimate_token_budget(text: str) -> dict[str, object]:
        result = calculate_token_budget(
            text,
            model=active_settings.model or None,
            encoding_name=active_settings.encoding_name,
            context_window=active_settings.context_window,
            reserved_output_tokens=active_settings.reserved_output_tokens,
            warn_ratio=active_settings.warn_ratio,
            enforce=False,
        )
        payload = result.to_dict()
        payload["policy"] = "observe"
        return payload

    @server.tool(
        name="run_agent_node",
        description=(
            "Run one bounded Agents SDK node. Requires canary mode, API key, and explicit model; "
            "handoffs, sessions, and tools are disabled."
        ),
        structured_output=True,
    )
    def run_agent_node(name: str, instructions: str, input_text: str) -> dict[str, object]:
        return execute(
            name=name,
            instructions=instructions,
            input_text=input_text,
            settings=active_settings,
        )

    return server


def main() -> None:
    create_server().run(transport="stdio")


if __name__ == "__main__":
    main()
