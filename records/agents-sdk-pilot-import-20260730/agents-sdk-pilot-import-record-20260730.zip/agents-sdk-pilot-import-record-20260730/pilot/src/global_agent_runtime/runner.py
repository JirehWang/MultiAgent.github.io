from __future__ import annotations

from collections.abc import Callable
from typing import Any

from agents import Agent, RunConfig, Runner

from .budget import estimate_token_budget
from .settings import RuntimeSettings


class AgentNodeUnavailable(RuntimeError):
    """Raised when the feature gates for model execution are not satisfied."""


def _usage_dict(result: Any) -> dict[str, int]:
    usage = result.context_wrapper.usage
    return {
        "requests": int(usage.requests),
        "input_tokens": int(usage.input_tokens),
        "output_tokens": int(usage.output_tokens),
        "total_tokens": int(usage.total_tokens),
    }


def run_agent_node(
    *,
    name: str,
    instructions: str,
    input_text: str,
    settings: RuntimeSettings,
    run_sync: Callable[..., Any] | None = None,
) -> dict[str, object]:
    if not settings.agent_execution_available:
        raise AgentNodeUnavailable(
            "agent execution requires canary mode, OPENAI_API_KEY, and AGENTS_SDK_MODEL"
        )

    budget = estimate_token_budget(
        f"{instructions}\n\n{input_text}",
        model=settings.model,
        encoding_name=settings.encoding_name,
        context_window=settings.context_window,
        reserved_output_tokens=settings.reserved_output_tokens,
        warn_ratio=settings.warn_ratio,
        enforce=True,
    )

    agent = Agent(
        name=name,
        instructions=instructions,
        model=settings.model,
        tools=[],
        handoffs=[],
        mcp_servers=[],
    )
    run_config = RunConfig(
        workflow_name="global-agents-sdk-pilot",
        tracing_disabled=not settings.tracing_enabled,
        trace_include_sensitive_data=False,
    )
    execute = run_sync or Runner.run_sync
    result = execute(
        agent,
        input_text,
        max_turns=settings.max_turns,
        run_config=run_config,
        session=None,
    )

    return {
        "output": str(result.final_output),
        "model": settings.model,
        "max_turns": settings.max_turns,
        "estimated_budget": budget.to_dict(),
        "actual_usage": _usage_dict(result),
        "handoffs_used": False,
        "session_used": False,
        "tools_used": False,
    }
