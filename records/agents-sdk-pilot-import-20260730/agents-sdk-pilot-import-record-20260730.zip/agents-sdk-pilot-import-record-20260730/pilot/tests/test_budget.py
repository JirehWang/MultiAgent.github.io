import tiktoken
import unittest

from global_agent_runtime.budget import BudgetExceeded, estimate_token_budget


class TokenBudgetTests(unittest.TestCase):
    def test_empty_text_is_within_budget(self):
        result = estimate_token_budget("", context_window=100, reserved_output_tokens=10)

        self.assertEqual(result.estimated_input_tokens, 0)
        self.assertEqual(result.remaining_tokens, 90)
        self.assertEqual(result.status, "ok")

    def test_estimate_matches_selected_encoding(self):
        text = "Global workflow token observation."
        expected = len(tiktoken.get_encoding("o200k_base").encode(text))

        result = estimate_token_budget(
            text,
            encoding_name="o200k_base",
            context_window=100,
            reserved_output_tokens=10,
        )

        self.assertEqual(result.estimated_input_tokens, expected)
        self.assertEqual(result.encoding, "o200k_base")

    def test_warns_before_context_is_exceeded(self):
        text = " ".join(["token"] * 60)

        result = estimate_token_budget(
            text,
            context_window=80,
            reserved_output_tokens=10,
            warn_ratio=0.70,
        )

        self.assertEqual(result.status, "warn")
        self.assertGreaterEqual(result.utilization, 0.70)
        self.assertLessEqual(result.utilization, 1)

    def test_enforce_rejects_exceeded_budget(self):
        text = " ".join(["token"] * 60)

        with self.assertRaises(BudgetExceeded):
            estimate_token_budget(
                text,
                context_window=30,
                reserved_output_tokens=10,
                enforce=True,
            )

    def test_unknown_model_falls_back_to_configured_encoding(self):
        result = estimate_token_budget(
            "hello",
            model="not-a-real-model",
            encoding_name="cl100k_base",
            context_window=100,
            reserved_output_tokens=10,
        )

        self.assertEqual(result.encoding, "cl100k_base")
        self.assertFalse(result.used_model_encoding)
