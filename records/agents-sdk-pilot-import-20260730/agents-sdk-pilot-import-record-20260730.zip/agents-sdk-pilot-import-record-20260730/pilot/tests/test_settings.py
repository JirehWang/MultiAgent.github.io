import unittest

from global_agent_runtime.settings import RuntimeSettings


class RuntimeSettingsTests(unittest.TestCase):
    def test_observe_mode_never_enables_agent_execution(self):
        settings = RuntimeSettings.from_env(
            {
                "AGENTS_SDK_PILOT_MODE": "observe",
                "OPENAI_API_KEY": "secret",
                "AGENTS_SDK_MODEL": "explicit-model",
            }
        )

        self.assertFalse(settings.agent_execution_available)

    def test_canary_requires_api_key_and_explicit_model(self):
        without_key = RuntimeSettings.from_env(
            {
                "AGENTS_SDK_PILOT_MODE": "canary",
                "AGENTS_SDK_MODEL": "explicit-model",
            }
        )
        without_model = RuntimeSettings.from_env(
            {
                "AGENTS_SDK_PILOT_MODE": "canary",
                "OPENAI_API_KEY": "secret",
            }
        )

        self.assertFalse(without_key.agent_execution_available)
        self.assertFalse(without_model.agent_execution_available)

    def test_canary_is_available_only_when_all_gates_are_present(self):
        settings = RuntimeSettings.from_env(
            {
                "AGENTS_SDK_PILOT_MODE": "canary",
                "OPENAI_API_KEY": "secret",
                "AGENTS_SDK_MODEL": "explicit-model",
            }
        )

        self.assertTrue(settings.agent_execution_available)

    def test_public_status_never_contains_secret_value(self):
        settings = RuntimeSettings.from_env(
            {
                "AGENTS_SDK_PILOT_MODE": "canary",
                "OPENAI_API_KEY": "do-not-leak",
                "AGENTS_SDK_MODEL": "explicit-model",
            }
        )

        status = settings.public_status()

        self.assertTrue(status["api_key_present"])
        self.assertNotIn("do-not-leak", repr(status))

    def test_max_turns_is_capped(self):
        settings = RuntimeSettings.from_env(
            {
                "AGENTS_SDK_MAX_TURNS": "999",
            }
        )

        self.assertEqual(settings.max_turns, 4)
