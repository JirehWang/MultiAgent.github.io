from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


RUNTIME_ROOT = Path(
    os.environ.get(
        "PILOT_RUNTIME_ROOT",
        r"C:\Users\105221\Documents\Codex\global-runtimes\agents-sdk-pilot",
    )
)


async def verify() -> dict[str, object]:
    python = RUNTIME_ROOT / ".venv" / "Scripts" / "python.exe"
    server_env = dict(os.environ)
    server_env.update(
        {
            "PYTHONPATH": str(RUNTIME_ROOT / "src"),
            "TIKTOKEN_CACHE_DIR": str(RUNTIME_ROOT / "tiktoken-cache"),
            "AGENTS_SDK_PILOT_MODE": "observe",
            "AGENTS_SDK_ENCODING": "o200k_base",
            "AGENTS_SDK_CONTEXT_WINDOW": "200000",
            "AGENTS_SDK_RESERVED_OUTPUT_TOKENS": "8000",
            "AGENTS_SDK_WARN_RATIO": "0.80",
            "AGENTS_SDK_MAX_TURNS": "4",
            "AGENTS_SDK_TRACING_ENABLED": "false",
            "OPENAI_AGENTS_DISABLE_TRACING": "1",
        }
    )
    server_env.pop("OPENAI_API_KEY", None)
    parameters = StdioServerParameters(
        command=str(python),
        args=["-m", "global_agent_runtime.server"],
        env=server_env,
    )

    async with stdio_client(parameters) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:
            await session.initialize()
            listed = await session.list_tools()
            tool_names = sorted(tool.name for tool in listed.tools)
            expected = [
                "estimate_token_budget",
                "run_agent_node",
                "runtime_status",
            ]
            if tool_names != expected:
                raise AssertionError(f"unexpected tools: {tool_names}")

            status_result = await session.call_tool("runtime_status", {})
            status = status_result.structuredContent
            if status_result.isError or status is None:
                raise AssertionError("runtime_status failed")
            if status["mode"] != "observe":
                raise AssertionError(f"unexpected mode: {status['mode']}")
            if status["agent_execution_available"]:
                raise AssertionError("model execution must be disabled in observe mode")

            estimate_result = await session.call_tool(
                "estimate_token_budget",
                {"text": "Token observation integration test."},
            )
            estimate = estimate_result.structuredContent
            if estimate_result.isError or estimate is None:
                raise AssertionError("estimate_token_budget failed")
            if estimate["estimated_input_tokens"] <= 0:
                raise AssertionError("token estimate must be positive")

            return {
                "tools": tool_names,
                "mode": status["mode"],
                "agent_execution_available": status["agent_execution_available"],
                "openai_agents_version": status["openai_agents_version"],
                "tiktoken_version": status["tiktoken_version"],
                "estimated_input_tokens": estimate["estimated_input_tokens"],
                "token_status": estimate["status"],
            }


if __name__ == "__main__":
    print(json.dumps(asyncio.run(verify()), indent=2, sort_keys=True))
