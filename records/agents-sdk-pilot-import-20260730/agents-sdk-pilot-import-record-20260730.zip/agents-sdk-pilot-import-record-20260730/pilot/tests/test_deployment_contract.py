from pathlib import Path
import unittest


PROJECT_ROOT = Path(__file__).resolve().parents[1]
STAGED_ROOT = PROJECT_ROOT / "staged-global"


class DeploymentContractTests(unittest.TestCase):
    def test_config_registers_observe_mode_without_persisting_an_api_key(self):
        config = (STAGED_ROOT / "config.toml").read_text(encoding="utf-8")

        self.assertIn("[mcp_servers.agents_sdk_pilot]", config)
        self.assertIn('AGENTS_SDK_PILOT_MODE = "observe"', config)
        self.assertIn("OPENAI_AGENTS_DISABLE_TRACING", config)
        self.assertNotIn("OPENAI_API_KEY =", config)

    def test_router_keeps_control_plane_and_disables_overlapping_sdk_features(self):
        rules = (
            STAGED_ROOT
            / "skills"
            / "using-superpowers"
            / "agent-routing-rules.yaml"
        ).read_text(encoding="utf-8")

        self.assertIn("control_plane_owner: using-superpowers", rules)
        self.assertIn("rollout_mode: observe", rules)
        self.assertIn("- handoffs", rules)
        self.assertIn("- sessions", rules)
        self.assertIn("- direct-tools", rules)

    def test_router_skill_contains_the_observe_policy(self):
        skill = (
            STAGED_ROOT / "skills" / "using-superpowers" / "SKILL.md"
        ).read_text(encoding="utf-8")
        policy = (
            STAGED_ROOT
            / "skills"
            / "using-superpowers"
            / "AGENTS_SDK_PILOT_ROUTING.md"
        ).read_text(encoding="utf-8")

        self.assertIn("bounded execution-node runtime", skill)
        self.assertIn("do not route model execution", skill)
        self.assertIn("Status: observe", policy)
        self.assertIn("no handoffs, no session, no tools", policy)
