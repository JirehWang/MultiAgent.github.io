import asyncio
import unittest

from global_agent_runtime.server import create_server
from global_agent_runtime.settings import RuntimeSettings


class McpServerTests(unittest.TestCase):
    def test_server_exposes_only_the_pilot_contract(self):
        settings = RuntimeSettings.from_env(
            {
                "AGENTS_SDK_PILOT_MODE": "observe",
            }
        )
        server = create_server(settings=settings)

        tools = asyncio.run(server.list_tools())

        self.assertEqual(
            {tool.name for tool in tools},
            {"runtime_status", "estimate_token_budget", "run_agent_node"},
        )

    def test_status_is_read_only_and_reports_observe_mode(self):
        settings = RuntimeSettings.from_env(
            {
                "AGENTS_SDK_PILOT_MODE": "observe",
            }
        )
        server = create_server(settings=settings)

        _, status = asyncio.run(server.call_tool("runtime_status", {}))

        self.assertEqual(status["mode"], "observe")
        self.assertFalse(status["agent_execution_available"])
        self.assertFalse(status["handoffs_enabled"])
