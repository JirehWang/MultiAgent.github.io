from types import SimpleNamespace
import unittest

from global_agent_runtime.runner import AgentNodeUnavailable, run_agent_node
from global_agent_runtime.settings import RuntimeSettings


def canary_settings(**overrides):
    env = {
        "AGENTS_SDK_PILOT_MODE": "canary",
        "OPENAI_API_KEY": "test-key",
        "AGENTS_SDK_MODEL": "test-model",
        "AGENTS_SDK_CONTEXT_WINDOW": "200",
        "AGENTS_SDK_RESERVED_OUTPUT_TOKENS": "20",
        "AGENTS_SDK_MAX_TURNS": "4",
    }
    env.update(overrides)
    return RuntimeSettings.from_env(env)


class AgentNodeRunnerTests(unittest.TestCase):
    def test_observe_mode_rejects_before_model_call(self):
        called = False

        def fake_run_sync(*args, **kwargs):
            nonlocal called
            called = True
            raise AssertionError("model runner must not be called")

        settings = canary_settings(AGENTS_SDK_PILOT_MODE="observe")

        with self.assertRaises(AgentNodeUnavailable):
            run_agent_node(
                name="pilot",
                instructions="Analyze.",
                input_text="input",
                settings=settings,
                run_sync=fake_run_sync,
            )

        self.assertFalse(called)

    def test_canary_builds_single_agent_without_handoffs_sessions_or_tools(self):
        captured = {}
        usage = SimpleNamespace(
            requests=1,
            input_tokens=7,
            output_tokens=3,
            total_tokens=10,
        )

        def fake_run_sync(agent, input_text, **kwargs):
            captured["agent"] = agent
            captured["input_text"] = input_text
            captured["kwargs"] = kwargs
            return SimpleNamespace(
                final_output="done",
                context_wrapper=SimpleNamespace(usage=usage),
            )

        result = run_agent_node(
            name="pilot",
            instructions="Analyze.",
            input_text="input",
            settings=canary_settings(),
            run_sync=fake_run_sync,
        )

        agent = captured["agent"]
        kwargs = captured["kwargs"]
        self.assertEqual(agent.tools, [])
        self.assertEqual(agent.handoffs, [])
        self.assertEqual(agent.mcp_servers, [])
        self.assertIsNone(kwargs["session"])
        self.assertEqual(kwargs["max_turns"], 4)
        self.assertTrue(kwargs["run_config"].tracing_disabled)
        self.assertFalse(kwargs["run_config"].trace_include_sensitive_data)
        self.assertEqual(result["output"], "done")
        self.assertEqual(result["actual_usage"]["total_tokens"], 10)

    def test_budget_is_enforced_before_model_call(self):
        called = False

        def fake_run_sync(*args, **kwargs):
            nonlocal called
            called = True
            raise AssertionError("model runner must not be called")

        settings = canary_settings(
            AGENTS_SDK_CONTEXT_WINDOW="30",
            AGENTS_SDK_RESERVED_OUTPUT_TOKENS="10",
        )

        with self.assertRaises(ValueError):
            run_agent_node(
                name="pilot",
                instructions="Analyze.",
                input_text=" ".join(["token"] * 100),
                settings=settings,
                run_sync=fake_run_sync,
            )

        self.assertFalse(called)
