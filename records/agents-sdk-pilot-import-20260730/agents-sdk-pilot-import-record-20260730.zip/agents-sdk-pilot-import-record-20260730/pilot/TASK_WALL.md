# Task wall

| ID | Task | Status | Evidence |
|---|---|---|---|
| T1 | Inspect current global control plane | done | Declarative Codex router; no Python host |
| T2 | Create rollback checkpoint | done | 67/67 hashes verified |
| T3 | Protect runtime behavior with tests | done | 18/18 passed |
| T4 | Build and deploy MCP pilot | done | Codex lists enabled MCP |
| T5 | Observe canary, rollback drill, state gate | done | Token call passed; model call denied by design |

## Gate result

Accepted for observe-mode production use.

Not promoted to model-execution canary because no `OPENAI_API_KEY` or explicit
`AGENTS_SDK_MODEL` is configured. This is an intentional gate, not a failed rollout.
