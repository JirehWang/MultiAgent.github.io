# Agents SDK Pilot 導入紀錄

此資料夾保存 2026-07-29 至 2026-07-30 的 `openai-agents-python` 與
`tiktoken` 全域 workflow pilot，供日後移轉到個人電腦重新部署。

封存完成後，公司電腦的全域 workflow 會回退至導入前 checkpoint。

## 封存內容

- `pilot/`：可攜的 Python 原始碼、測試、`pyproject.toml` 與 tiktoken cache。
- `global-before/`：導入前的 router skill 與 routing rules。
- `global-after/`：導入後的 router skill 與 routing rules。
- `CONFIG-PILOT-BLOCK.toml`：需要加入個人電腦 `config.toml` 的 MCP 範本。
- `DEPENDENCIES.txt`：公司電腦 pilot virtualenv 的 dependency freeze。
- `TEST-RESULTS.md`：真實測試結果，包括成功與公司沙箱錯誤。
- `ROLLBACK-RECORD.md`：公司電腦回退範圍與 checkpoint 證據。
- `evidence/`：E2E 日誌、原始 verifier、app-server smoke script 與 rules 修正紀錄。

此封存不含：

- `.venv`
- OpenAI API key
- Codex `auth.json`
- GitHub token
- 公司帳號憑證

## 個人電腦部署順序

1. 安裝 Python 3.10 或 3.11，以及最新版 Codex Desktop/CLI。
2. 將 `pilot/` 複製到個人電腦的固定 runtime 目錄。
3. 在 runtime 目錄建立 venv：

```powershell
$pilotRuntime = 'C:\Users\<USER>\Documents\Codex\global-runtimes\agents-sdk-pilot'
py -3.11 -m venv "$pilotRuntime\.venv"
& "$pilotRuntime\.venv\Scripts\python.exe" -m pip install --upgrade pip
& "$pilotRuntime\.venv\Scripts\python.exe" -m pip install -e $pilotRuntime
```

4. 將 `CONFIG-PILOT-BLOCK.toml` 的 `<RUNTIME_ROOT>` 換成實際絕對路徑，再合併到個人電腦的 `~/.codex/config.toml`。
5. 比較 `global-before/` 與 `global-after/`，只合併 Agents SDK pilot 差異。若個人電腦的 router baseline 不同，不可直接覆寫整個檔案。
6. 保持 `AGENTS_SDK_PILOT_MODE="observe"`，先不要設定 API key，也不要啟用 agent execution。
7. 在一般 PowerShell 執行測試，不要從 Codex Desktop task 裡再巢狀啟動 Codex。

## 最低驗證

```powershell
$pilotRuntime = 'C:\Users\<USER>\Documents\Codex\global-runtimes\agents-sdk-pilot'
$env:PYTHONPATH = "$pilotRuntime\src"
$env:TIKTOKEN_CACHE_DIR = "$pilotRuntime\tiktoken-cache"
& "$pilotRuntime\.venv\Scripts\python.exe" -m unittest discover -s "$pilotRuntime\tests" -v
codex mcp list
```

通過單元測試與 MCP listing 後，再執行 `evidence/run-real-app-server-smoke.ps1`。
只有 app-server、router 與 `estimate_token_budget` 都產生實際事件，才算完整 E2E 通過。
