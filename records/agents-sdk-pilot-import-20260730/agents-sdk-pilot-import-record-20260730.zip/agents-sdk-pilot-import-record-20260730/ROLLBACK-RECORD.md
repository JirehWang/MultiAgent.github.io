# 公司電腦回退紀錄

目標 checkpoint：

`global-workflow-pre-agents-sdk-20260729-160533`

Checkpoint archive SHA256：

`717E0B879D4235541DFAE940B70FD122A7D06EBD2371BD7CBB85F394E4AA99D4`

Checkpoint manifest：

- 67 個檔案
- rollback 前重新驗證 67/67 hash 相符
- restore guard 在沒有 `-ConfirmRestore` 時 exit code 1
- guard 訊息：`Restore not started`

與 checkpoint 相比，導入造成變動的全域檔案只有：

1. `config.toml`
2. `skills/using-superpowers/SKILL.md`
3. `skills/using-superpowers/agent-routing-rules.yaml`

Restore script 會以 checkpoint 覆寫上述檔案及 manifest 所列的既有 global
workflow files。它不會刪除：

- `C:\Users\105221\Documents\Codex\global-runtimes\agents-sdk-pilot`
- 本封存資料夾
- `default.rules` 的 Starlark comment 修正

保留 runtime 是刻意決定，目的為稍後移轉至個人電腦；全域 MCP 註冊則由
checkpoint `config.toml` 移除。
