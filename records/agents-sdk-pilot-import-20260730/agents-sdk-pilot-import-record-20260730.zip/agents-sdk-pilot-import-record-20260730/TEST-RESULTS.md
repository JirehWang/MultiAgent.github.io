# 測試結果

測試日期：2026-07-30

## 通過

- Python unit/contract tests：18/18，exit code 0。
- TOML 與 YAML 可解析。
- Pilot MCP tool contract：
  - `runtime_status`
  - `estimate_token_budget`
  - `run_agent_node`
- observe mode 下 `run_agent_node` 被拒絕。
- 先前直接 MCP protocol 測試的 token estimate 為 5。

## 未通過

公司 Codex Desktop 沙箱內的 stdio MCP integration，exit code 1。

實際錯誤：

```text
PermissionError: [WinError 5] 存取被拒。
```

錯誤發生於 Python `asyncio` 建立 Windows subprocess pipe：

```text
asyncio.windows_utils.pipe
_winapi.CreateFile
```

完整 global workflow E2E 也未通過。rules 解析成功，但巢狀
`codex exec` 在 app-server/runtime 權限邊界停止，沒有 router 或 MCP tool-call 事件。

## 判定

Pilot 內部邏輯與契約測試通過；公司 Desktop 沙箱不允許完成真實的
app-server/stdin-stdout subprocess 邊界。因此此電腦不宣告 E2E 上線成功。

個人電腦應在一般 PowerShell 重新執行完整 E2E，不得沿用公司電腦的通過判定。
